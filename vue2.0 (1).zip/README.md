#Vue2.0脚手架--轻量级。


# 使用方法。
npm install
* 创建项目
gulp init --origin=项目名称
* 本地预览
gulp test --origin=项目名称(local online)
$ gulp watch --origin=项目名称